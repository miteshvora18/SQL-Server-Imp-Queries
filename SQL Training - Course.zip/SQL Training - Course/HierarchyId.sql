CREATE TABLE Employees
(
	EmpID INT,
	Name VARCHAR(20),
	Position HierarchyID,
	Level AS Position.GetLevel() PERSISTED
);
 
INSERT INTO Employees
   VALUES(1, 'Steven', hierarchyid::GetRoot());
 
SELECT EmpID, Name, Position.ToString() as Position, Level
    FROM Employees;
 
DECLARE @Parent HierarchyID 
SELECT  @Parent = Position
  FROM Employees
  WHERE EmpID = 1
 --SELECT @Parent.ToString()
 INSERT INTO Employees
   VALUES(2, 'Neena', @Parent.GetDescendant(NULL, NULL) )
  
  
 -- Add second child.
DECLARE @Parent HierarchyID
DECLARE @FirstChild HierarchyID
SELECT @Parent = HierarchyID::GetRoot()
SELECT  @FirstChild = @Parent.GetDescendant(NULL, NULL) 
INSERT INTO Employees
  VALUES(3, 'Lex', @Parent.GetDescendant(@FirstChild, NULL)) 

-- Add First Grand child.
DECLARE @Parent HierarchyID
SELECT @Parent = Position
    FROM Employees
   WHERE EmpID = 2 
INSERT INTO Employees
  VALUES(4, 'Nancy', @Parent.GetDescendant(NULL, NULL))

 -- Add second grand child.
DECLARE @Parent HierarchyID
DECLARE @FirstChild HierarchyID
SELECT @Parent = Position
    FROM Employees
   WHERE EmpID = 2 
SELECT  @FirstChild = @Parent.GetDescendant(NULL, NULL) 
INSERT INTO Employees
  VALUES(5, 'Andrew', @Parent.GetDescendant(@FirstChild, NULL))
 
  SELECT EmpID, Name, Position.ToString(), Level
    FROM Employees;

--Find last child of Steven.
DECLARE @Parent HierarchyID
DECLARE @LastChild HierarchyID
DECLARE @Name varchar(20)
SELECT @Parent = HierarchyID::GetRoot()
--SELECT @LastChild = @Parent.GetDescendant(Max(Position), NULL)
--    FROM Employees

	SELECT @Name = Name,@LastChild = Position
    FROM Employees
	where Position.IsDescendantOf(@Parent) = 1
	 
   SELECT @LastChild.ToString(),@Name
