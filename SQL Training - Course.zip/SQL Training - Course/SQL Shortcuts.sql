--This is line 1

--This is line 2 

--This is line 3 


--Ctrl+Shift+V to get previous copy data

--Tools->Code snippet manager -> Add -> Folder where snippet kept -> OK 
--Right click and InsertSnippet -> Got to above folder -> Insert snippet 
declare @count int = 1 
WHILE( @count )
BEGIN
	
	DECLARE @x int = 10

END
