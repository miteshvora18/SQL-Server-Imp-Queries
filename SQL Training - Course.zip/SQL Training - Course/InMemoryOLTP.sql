--In MEMORY OLTP
--Create Database InMemoryOLTP
--2.Create 2 tables. 1.Disk based table and other one is InMemoryTable

CREATE TABLE DiskTable
(
	id int primary key,
	name varchar(20) not null
)

--Schema & data both by default
CREATE TABLE InMemoryTable
(
	id int,
	name varchar(20) not null,
	CONSTRAINT InMemoryTable_PK primary key
	NONCLUSTERED HASH(id)  --Hashing Algorithm
	WITH (BUCKET_COUNT = 1000000) --Total no. of rows
)
WITH (MEMORY_OPTIMIZED = ON); 

--Schema only
CREATE TABLE InMemoryTable
(
	id int,
	name varchar(20) not null,
	CONSTRAINT InMemoryTable_PK primary key
	NONCLUSTERED HASH(id)  --Hashing Algorithm
	WITH (BUCKET_COUNT = 1000000) --Total no. of rows
)
WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY); 

--Create 2 SP.

CREATE PROC PrcInsertInDiskTable
AS
BEGIN
	DECLARE @Start datetime,@End Datetime,@Name varchar(20),@Count int =1
	SET NOCOUNT ON
	SET @Start = GETDATE()
		BEGIN TRAN
			WHILE (@Count <= 100000)
			BEGIN
				SET @Name = 'Emp' + Convert(varchar,@count)
				INSERT INTO DiskTable
				VALUES(@Count,@Name);

				SET @Count = @Count + 1;
			END

		COMMIT 

		SET @End = getdate()
		SELECT DATEDIFF(MILLISECOND,@Start,@End) as 'Duration in Sec.'
END
GO

--InMemoryTable
ALTER PROC PrcInsertInMemoryTable WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC  WITH(TRANSACTION ISOLATION LEVEL = SNAPSHOT,LANGUAGE = 'ENGLISH')
	DECLARE @Start datetime,@End Datetime,@Name varchar(20),@Count int =1
	
	SET @Start = GETDATE()
			WHILE (@Count <= 100000)
			BEGIN
				SET @Name = 'Emp' + Convert(varchar,@count)
				INSERT INTO dbo.InMemoryTable
				VALUES(@Count,@Name);

				SET @Count = @Count + 1;
			END

		SET @End = getdate()
		SELECT DATEDIFF(MILLISECOND,@Start,@End) as 'Duration in Sec.'
END
GO

set statistics io on
set statistics time on
--exec PrcInsertInDiskTable
exec PrcInsertInMemoryTable

select * from DiskTable
select * from InMemoryTable


--Restart the SQL Server and test the data 
select * from DiskTable
select * from InMemoryTable