sp_configure 'show advanced options',1
reconfigure

--check
sp_configure 'max server memory'

--Set max server memory to 4GB
sp_configure 'max server memory',4096
reconfigure

--check
sp_configure 'max server memory'

--enable buffer pool extension
ALTER SERVER CONFIGURATION
SET BUFFER POOL EXTENSION ON
(FILENAME = 'D:\BPE\SQL_BPE.bpe',SIZE=2 GB);

--check buffer pool
select * from sys.dm_os_buffer_pool_extension_configuration

SET STATISTICS IO ON 
SET STATISTICS TIME ON  
--run query
select * from dbo.FactResellerSales	


insert into factproductinventorycopy
select * from factproductinventory

select * from sys.dm_os_buffer_descriptors
where database_id = db_id('AdventureWorksDW2016')
and is_in_bpool_extension = 1


ALTER SERVER CONFIGURATION
SET BUFFER POOL EXTENSION Off