--1
--DROP PK
DROP INDEX PK_FACTPRODUCTINVENTORY
ON FACTPRODUCTINVENTORY



CREATE COLUMNSTORE INDEX
PRODUCTINVENTORY_NCS ON FACTPRODUCTINVENTORY
(
	PRODUCTKEY,
	[DateKey],
	[UnitsIn],
	[UnitsOut],
	[UnitsBalance]
)

SET STATISTICS IO ON 
SET STATISTICS TIME ON 
SELECT [ProductKey]
      ,[DateKey]
      ,sum([UnitsIn]) as TotalUnitsIn
      ,SUM([UnitsOut]) AS TOTALUNITSOUT
      ,SUM([UnitsBalance]) AS TOTALUNITSBALANCE
  FROM [AdventureWorksDW2016].[dbo].[FactProductInventory]
  GROUP BY ProductKey,DateKey--,MovementDate
  ORDER BY ProductKey,DateKey--,MovementDate

--2
DROP INDEX PRODUCTINVENTORY_NCS ON
FACTPRODUCTINVENTORY

ALTER TABLE FACTPRODUCTINVENTORY
ADD CONSTRAINT PK_FACTPRODUCTINVENTORY PRIMARY KEY (PRODUCTKEY,[DateKey]);


CREATE COLUMNSTORE INDEX
PRODUCTINVENTORY_NCS ON FACTPRODUCTINVENTORY
(
	PRODUCTKEY,
	[DateKey],
	[UnitsIn],
	[UnitsOut],
	[UnitsBalance]
)


SET STATISTICS IO ON 
SET STATISTICS TIME ON 
select p.ProductKey,p.EnglishProductName,d.DateKey,
SUM(UnitCost),
SUM(UnitsIn),
SUM(UnitsOut),
SUM(UnitsBalance)
 from FactProductInventory fpi 
 join DimProduct p
 on p.ProductKey=fpi.ProductKey
 join DimDate d on d.DateKey=fpi.DateKey
 group by p.ProductKey,p.EnglishProductName,d.DateKey
order by p.ProductKey,p.EnglishProductName,d.DateKey 