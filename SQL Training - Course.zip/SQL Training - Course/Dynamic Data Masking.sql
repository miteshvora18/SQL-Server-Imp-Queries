--Dynamic Data Masking
use AdventureWorks2016
----------------------------------------------------------------------------
--drop table ddmtab

CREATE TABLE DDMTAB
(
	Id int,
	Name varchar(20),
	Email varchar(30),
	Salary money,
	CreditCardNo varchar(16)
)
GO

----------------------------------------------------------------------------

INSERT INTO DDMTAB
VALUES(1,'Steven King','Sking@adventureworks.com',30000,'456564654654');

INSERT INTO DDMTAB
VALUES(2,'Andy Hillman','andy@adventureworks.com',40000,'45747987454654');

SELECT * FROM DDMTAB
----------------------------------------------------------------------------

--Enable DDM  DBCC-> Database Consistency Check
DBCC TRACEON(209,219,-1)

----------------------------------------------------------------------------

--Alter table to enable masking
ALTER TABLE DDMTAB
ALTER COLUMN SALARY 
ADD MASKED WITH(FUNCTION='default()');

ALTER TABLE DDMTAB
ALTER COLUMN Email
ADD MASKED WITH(FUNCTION='email()');

ALTER TABLE DDMTAB
ALTER COLUMN CREDITCARDNO
ADD MASKED WITH(FUNCTION='partial(2,"XXXX",2)');

SELECT * FROM DDMTAB

----------------------------------------------------------------------------

--CREATE A USER TO TEST DDM
CREATE USER DDMTESTUSER WITHOUT LOGIN; --Dummy User
GO

--GRANT PERMISSION TO DDM USER
GRANT SELECT ON DDMTAB TO DDMTESTUSER;
GO

--CHANGE THE USER CONTEXT
EXECUTE AS USER = 'DDMTESTUSER'
SELECT CURRENT_USER AS USERNAME
GO

--CHECK DATA (For other user it would be masked)
SELECT * FROM DDMTAB

--GO BACK TO 
REVERT;

SELECT CURRENT_USER --reverted to dbo i.e. System Admin

select USER_ID()

----------------------------------------------------------------------------
--Only System Admin will be able to see masked data
--irrespective of whoever created the same 

	