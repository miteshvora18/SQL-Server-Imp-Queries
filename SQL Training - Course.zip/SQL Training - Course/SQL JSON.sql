--JSON 
SELECT businessentityid,firstname,LastName
FROM Person.Person 
where businessentityid = 285
for JSON AUTO
--O/P
--[{"businessentityid":285,"firstname":"Syed","LastName":"Abbas"}]

--Alias
SELECT BusinessEntityID as BId,
FirstName as FName,
LastName as LName
FROM Person.Person 
where BusinessEntityID = 285
for JSON AUTO

--[{"BId":285,"FName":"Syed","LName":"Abbas"}]

--JSON Path
SELECT BusinessEntityID as 'Customer.BId',
FirstName as 'Customer.FName',
LastName as 'Customer.LName'
FROM Person.Person p
where BusinessEntityID in( 285,286)
for JSON PATH;

--[{"Customer":{"BId":285,"FName":"Syed","LName":"Abbas"}},{"Customer":{"BId":286,"FName":"Lynn","LName":"Tsoflias"}}]

--Join
select p.BusinessEntityID AS 'Person.ID',
 FirstName AS 'Person.FName',
 LastName AS 'Person.LName',
 e.JobTitle AS 'Employee.Designation',
 e.NationalIDNumber AS 'Employee.SSN'
from Person.Person p join HumanResources.Employee e 
on p.BusinessEntityID = e.BusinessEntityID
--where p.BusinessEntityID=285
 for JSON path; 

 --[{"Person":{"ID":285,"FName":"Syed","LName":"Abbas"},"Employee":{"Designation":"Pacific Sales Manager","SSN":"481044938"}}]