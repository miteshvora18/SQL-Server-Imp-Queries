--Mulitple row JSON
DECLARE @json NVARCHAR(MAX)
SET @json =  
N'[  
       { "id" : 2,"info": { "name": "John", "surname": "Smith" }, "age": 25 },  
       { "id" : 5,"info": { "name": "Jane", "surname": "Smith" }, "dob": "2005-11-04T12:00:00" }  
 ]'  

SELECT *  
FROM OPENJSON(@json)  
  WITH (id int 'strict $.id',  
        firstName nvarchar(50) '$.info.name', lastName nvarchar(50) '$.info.surname',  
        age int, dateOfBirth datetime2 '$.dob')  

-------------------------------------------------------------------------------------------------
--Order and Products
DECLARE @JsonText nvarchar(max)
Set @JsonText = N'{
				"Order":
				{
				"OrderID":12345,
				"Status":"Delivered",
				"PONumber":"PO1234501",
				"Product":[{
					"ProductID":45678,
					"Name":"Bike Stand"
					},
					{"ProductID":1245,
					"Name":"Water Bottle"
					}]
				}
	}';

--Retrive complete object
--SELECT * FROM OPENJSON(@JsonText)
--All orders 
--SELECT * FROM OPENJSON(@JsonText,'$.Order')

--First Product
--SELECT * FROM OPENJSON(@JsonText,'$.Order.Product[0]')

--Get Product Data
SELECT * FROM OPENJSON(@JsonText,'$')
WITH(OrderID int '$.Order.OrderID',
	Status varchar(10) '$.Order.Status',
	PONumber varchar(20) '$.Order.PONumber',
	ProductId int '$.Order.Product[0].ProductID',
	Name varchar(30) '$.Order.Product[0].Name'
	);


SELECT JSON_QUERY(@JsonText,'$.Order.Product') AS Product

--Create Table
CREATE TABLE [Order]
(
	OrderID int primary key,
	Status varchar(10),
	PONumber varchar(20),
)

CREATE TABLE Product
(
	ProductID int,
	Name varchar(20),
	OrderId int foreign key(OrderId) references [Order](OrderID)
)

--Store JSON Data
DECLARE @JsonText nvarchar(max)
Set @JsonText = N'{
				"Order":
				{
				"OrderID":12345,
				"Status":"Delivered",
				"PONumber":"PO1234501",
				"Product":[{
					"ProductID":45678,
					"Name":"Bike Stand"
					},
					{"ProductID":1245,
					"Name":"Water Bottle"
					}]
				}
	}';

--Insert in Order 
--INSERT INTO [Order]
--SELECT *  FROM OPENJSON(@JsonText,'$')
--WITH(OrderID int '$.Order.OrderID',
--	Status varchar(10) '$.Order.Status',
--	PONumber varchar(20) '$.Order.PONumber'
--	--ProductId int '$.Order.Product[0].ProductID',
--	--Name varchar(30) '$.Order.Product[0].Name'
--	);

--Product
insert into Product
 SELECT *  FROM OPENJSON(@JsonText,'$')
WITH(
	ProductId int '$.Order.Product[0].ProductID',
	Name varchar(30) '$.Order.Product[0].Name',
	OrderID int '$.Order.OrderID'
	);

insert into Product
SELECT *  FROM OPENJSON(@JsonText,'$')
WITH(
ProductId int '$.Order.Product[1].ProductID',
Name varchar(30) '$.Order.Product[1].Name',
OrderID int '$.Order.OrderID'
);

select * from Product