SSIS Deployment


CommandLine

dtexec \f "package1.dtsx"

Prior to SQL server 2012
Deployment Options:
1.File system
2.Package Store
3.SQL Server - MSDB only

Deployment Model:
1.Package Mode
	Options:
	1.File system
	2.Package Store
	3.SQL Server - MSDB only

From SQL Server 2012
Deployment Options:
1.File system
2.Package Store
3.SQL Server - MSDB only
4.SSIS DB

Deployment Model:
1.Package Mode
		Options:
		1.File system
		2.Package Store
		3.SQL Server - MSDB only
2.Project Mode
		Options:
		1.SSIS DB