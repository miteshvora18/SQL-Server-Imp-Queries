--Create Table
CREATE TABLE TestTemporal
(
	Id int primary key,
	A int,
	B int,
	C as A*B,
	SysStartTime datetime2 GENERATED ALWAYS AS ROW START NOT NULL,
	SysEndTime datetime2 GENERATED ALWAYS AS ROW END NOT NULL,
	PERIOD FOR SYSTEM_TIME(SysStartTime,SysEndTime) --SYSUTCDATETIME()
)
WITH (SYSTEM_VERSIONING = ON);

--Insert Rows
Insert into TestTemporal(ID,A,B)
values(1,2,3),(2,3,4),(3,4,5)

--Check Data
Select * from TestTemporal

update TestTemporal
set A=5
where id = 3;

delete from TestTemporal
where id = 2

--Query from History Table
select * from dbo.MSSQL_TemporalHistoryFor_1255675521

--Cannot drop Temporal Table
drop table TestTemporal
drop table dbo.MSSQL_TemporalHistoryFor_1255675521

--Allowed
alter table TestTemporal
add D int

--Disable versioning
alter table TestTemporal
set (SYSTEM_VERSIONING = OFF)

--Name History Table
alter table TestTemporal
set (SYSTEM_VERSIONING = ON
(History_table = dbo.Temporal_History,
	DATA_CONSISTENCY_CHECK = ON)
)

--If we add constraint with new rules with DATA_CONSISTENCY_CHECK = ON,
--Old records would also be validated and if not valid constraint would not run


