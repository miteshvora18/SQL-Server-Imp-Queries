--New Cardinality Estimator.
set statistics io on
set statistics time on
use AdventureWorks2016
go
--Change Compatibility_Level to SQL 2012
ALTER DATABASE AdventureWorks2016
SET COMPATIBILITY_LEVEL = 110
go
EXEC uspGetManagerEmployees 44

--Change Compatibility_Level to SQL 2014
ALTER DATABASE AdventureWorks2016
SET COMPATIBILITY_LEVEL = 120
go
EXEC uspGetManagerEmployees 44