--In MemoryOLTP Enhancements
--Alter table option available for most of the operations
--2.Adding constraints
--3.Can add PK,FK,Unique,NOT NULL and Check constraint
--4.Alter option available for Natively compiled SP/Fn
--5.Store Large data upto 2TB
--6.TDE(Transparent Data Encryption) support
--7.MARS(Multiple Active Result Set) support
--8.Support for complex subqueries
--9.Joins support
--10.Temporal Table Support
--11.Column Store index support (non clustered) (In memory doesen't support clustered indexes)

USE InMemoryOLTP

CREATE TABLE InMemoryTableNew
(
	SessionId int,
	UserId int,
	CreationDate datetime,
	INDEX InMemoryTableNew_UserId_Idx
	NONCLUSTERED HASH(UserId)
	WITH(BUCKET_COUNT = 1000000)
)
WITH(MEMORY_OPTIMIZED=ON,DURABILITY = SCHEMA_ONLY);


create index sessionId_idx on InMemoryTableNew(SessionID)

ALTER TABLE InMemoryTableNew
--alter column SessionID int not null
add constraint pk_sessionId primary key nonclustered( SessionID )

