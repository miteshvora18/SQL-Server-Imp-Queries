--Resource Governor
ALTER RESOURCE GOVERNOR RECONFIGURE


use [master]
go
CREATE FUNCTION [dbo].[FnClassifyConnections]()
	returns sysname
	with schemabinding
as 
begin
	declare @WorkloadGroupName sysname
	if SYSTEM_USER = 'login1' --
		set @WorkloadGroupName = 'DDGroup'
	else if SYSTEM_USER = 'indiaeclerx\mitesh.vora'
		set @WorkloadGroupName = 'L1_DBA'
	else
		set @WorkloadGroupName = 'Default'
	
	return @WorkloadGroupName
end	 

go

use [AdventureWorksDW2016]
select * from FactProductInventory

use [AdventureWorks2016]
select * from sales.SalesOrderDetail
order by ProductID
option (maxdop  1)

--create primary key not as clustered
create table tab1
(
	id int primary key nonclustered
)