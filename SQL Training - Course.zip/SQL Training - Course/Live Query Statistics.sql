
create index gender_idx on DimCustomer(Gender)
create index marital_idx on DimCustomer(MaritalStatus)

set statistics io on
set statistics time on
--Index Seek or Scan is decided by SQL server
select Gender ,MaritalStatus
from DimCustomer 
where Gender = 'f' and MaritalStatus = 'm'

--Seek
select Gender ,MaritalStatus
from DimCustomer WITH(FORCESEEK)
where Gender = 'f' and MaritalStatus = 'm'

--Scan 
select Gender ,MaritalStatus
from DimCustomer WITH(FORCESCAN)
where Gender = 'f' and MaritalStatus = 'm'

--Scan on clustered index
--Seek on nonclustered index
--More larger is data scan is better
