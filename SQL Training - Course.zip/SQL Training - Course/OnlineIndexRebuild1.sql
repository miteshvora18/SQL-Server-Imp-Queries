--CREATE PARTITION FUNCTION
--DEFINE THE RANGE OF VALUES
CREATE PARTITION FUNCTION FNPF(INT)
AS RANGE LEFT FOR VALUES(1,10,100)

--CREATE PARTITION SCHEME
--DEFINE value and partition mapping
create partition scheme FnPS
as partition fnpf to(FG1,FG2,FG3,FG4)

--1
--create partition table 
create table partitiontab
(
	id int ,
	value varchar(20)
)
on fnps(id);

--insert data 
declare @r int = -10
declare @msg varchar(20)
while(@r<= 150)
begin

	set @msg = 'Row ' + convert(varchar,@r)
	insert into partitiontab values(@r,@msg)
	set @r += 1
end


--confirm if data is partitioned 
select p.partition_number,p.rows
	from sys.objects o 
	join sys.partitions p on p.object_id = o.object_id 
	where o.object_id = object_id('Partitiontab') 


--2
--create partition scheme FnPS_Staging
--as partition fnpf to(FG1_S,FG2_S,FG3_S,FG4_S) 

--DROP TABLE partitiontab_staging
--create partition table 
create table partitiontab_staging
(
	id int ,
	value varchar(20)
)
on FnPS(id);

--REMOVE THE PARTITION FROM ORIGINAL TABLE AND MAP IT TO TARGET TABLE
ALTER TABLE PARTITIONTAB SWITCH PARTITION 1 TO partitiontab_staging PARTITION 1

SELECT * FROM partitiontab_staging

SELECT * FROM PARTITIONTAB


--create index
create index partitiontab_IX on partitiontab(ID)



--confirm if data is partitioned

select p.partition_number, p.rows
from sys.indexes o join sys.partitions p on p.object_id = o.object_id where o.object_id = OBJECT_ID('partitionTab') 

--insert data
declare @i int=-50;
declare @msg varchar(20)
while(@i<=-10)
begin
set @msg = 'Row ' + convert(varchar,@i)
insert into partitionTab_Staging values(@i,@msg)

set @i = @i + 1;
end

create index partitionTab_Staging_IX on partitionTab_Staging(ID)

alter table partitionTab_Staging switch partition 1 to  partitiontab partition 1; 

SELECT * FROM partitiontab

SELECT * FROM partitiontab_staging

--REBUILD
ALTER INDEX PARTITIONTAB_ix ON PARTITIONTAB
REBUILD PARTITION = 1 WITH (ONLINE=ON)

SELECT MAX(PARTITION_NUMBER)
FROM SYS.dm_db_partition_stats
WHERE OBJECT_ID = OBJECT_ID('PARTITIONTAB')





