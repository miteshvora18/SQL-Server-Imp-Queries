create table employee
(
EmpID int,
FName varchar(50),
Lname varchar(50),
DeptID int,
HireDate datetime,
LastDate datetime
)


create clustered COLUMNSTORE INDEX employee_CCS ON employee

DECLARE @INTID INT = 0
WHILE(@INTID < 1000000)
BEGIN
	insert into employee values(101,'nacyTYRTYRTYRTYRTYRTYRTYRTYRTYTRYRTYFGDFGDFG','gb',20,'2010-01-01',null)
	insert into employee values(102,'TEST','gb',20,'2010-01-01',null)
	insert into employee values(103,'TEST1','gb',20,'2010-01-01',null)
	insert into employee values(104,'TEST2','gb',20,'2010-01-01',null)
	insert into employee values(105,'TEST3','gb',20,'2010-01-01',null)
	insert into employee values(106,'TEST4','gb',20,'2010-01-01',null)
	SET @INTID = @INTID + 1
END

select * from sys.column_store_row_groups where OBJECT_ID=OBJECT_ID('employee'); 

--compress here
ALTER INDEX employee_CCS ON EMPLOYEE REBUILD

SELECT * FROM employee

select * from sys.stats
