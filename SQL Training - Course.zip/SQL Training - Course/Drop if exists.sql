
--String Split
select *  from  STRING_SPLIT('a,b,ac,asd,d,e,',',')
select *  from  STRING_SPLIT('a.b.ac.asd.d.e','.')

use AdventureWorks2016

--Create Table
Create Table Tab1
(
	A int,
	B int
)


--drop table if exists
IF EXISTS(SELECT OBJECT_ID FROM SYS.OBJECTS WHERE TYPE = 'U' AND NAME='TAB1')
BEGIN
	DROP TABLE TAB1
END

DROP TABLE IF EXISTS TAB1;