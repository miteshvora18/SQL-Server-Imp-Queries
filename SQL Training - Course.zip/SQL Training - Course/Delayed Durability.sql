create database delayeddurability

use [delayeddurability]
create table durabilitytest
(
	id int,
	name varchar(20),
	salary money 
)

--set the durability for db allowed/forced/disable
--ALLOWED ON TXN, FORCED -> EACH TXN IS 
ALTER DATABASE delayeddurability
	SET DELAYED_DURABILITY = allowed;
GO

--Full Durability
ALTER PROC PrcFullDurability
AS
BEGIN
	DECLARE @Start datetime,@End Datetime,@Name varchar(20),@Count int =1
	SET NOCOUNT ON
	SET @Start = GETDATE()
		BEGIN TRAN
			WHILE (@Count <= 1000)
			BEGIN
				SET @Name = 'Emp' + Convert(varchar,@count)
				INSERT INTO durabilitytest
				VALUES(@Count,@Name,30000);

				SET @Count = @Count + 1;
			END

		COMMIT WITH(DELAYED_DURABILITY = OFF)

		SET @End = getdate()
		SELECT DATEDIFF(MILLISECOND,@Start,@End) as 'Duration in Sec.'
END
GO


--DELAYED Durability
alter PROC PrcDelayedDurability
AS
BEGIN
	DECLARE @Start datetime,@End Datetime,@Name varchar(20),@Count int =1
	SET NOCOUNT ON
	SET @Start = GETDATE()
		BEGIN TRAN

			WHILE (@Count <= 1000)
			BEGIN
				SET @Name = 'Emp' + Convert(varchar,@count)
				INSERT INTO durabilitytest
				VALUES(@Count,@Name,30000);

				SET @Count = @Count + 1;
			END 

		COMMIT WITH(DELAYED_DURABILITY = ON)

		SET @End = getdate()
		SELECT DATEDIFF(MILLISECOND,@Start,@End) as 'Duration in Sec.'
END
GO

--DEFAULT DURABILITY
ALTER PROC PrcDefaultDurability
AS
BEGIN
	DECLARE @Start datetime,@End Datetime,@Name varchar(20),@Count int =1
	SET NOCOUNT ON
	SET @Start = GETDATE()
		BEGIN TRAN
			WHILE (@Count <= 1000)
			BEGIN
				SET @Name = 'Emp' + Convert(varchar,@count)
				INSERT INTO durabilitytest
				VALUES(@Count,@Name,30000);

				SET @Count = @Count + 1;
			END

		COMMIT 

		SET @End = getdate()
		SELECT DATEDIFF(MILLISECOND,@Start,@End) as 'Duration in Sec.'
END
GO

set statistics io on
set statistics time on
exec PrcFullDurability

EXEC PrcDelayedDurability

exec PrcDefaultDurability