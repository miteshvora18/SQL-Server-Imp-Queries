string connstring = "Data Source=.;Database=AEDemo;Integrated Security=true;Column Encryption Setting=Enabled";
            using (SqlConnection conn = new SqlConnection(connstring))
            {
                //Insert data 
                /*
                string sqlstatement = "PrcAdd";
                using (SqlCommand cmd = new SqlCommand(sqlstatement, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter p1 = new SqlParameter("@LastName", System.Data.SqlDbType.NVarChar);
                    p1.Value = "mall";
                    cmd.Parameters.Add(p1);

                    SqlParameter p2 = new SqlParameter("@Salary", System.Data.SqlDbType.Money);
                    p2.Value = "30000";
                    cmd.Parameters.Add(p2);
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.ExecuteNonQuery();
                }
                 * */


                //Get data
                string sqlstatement = "PrcGetByLastName";
                using (SqlCommand cmd = new SqlCommand(sqlstatement, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter p1 = new SqlParameter("@LastName", System.Data.SqlDbType.NVarChar);
                    p1.Value = "mall";
                    cmd.Parameters.Add(p1);

                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string id = dr["Id"].ToString();
                        string salary = dr["Salary"].ToString();
                    }
                }
            }